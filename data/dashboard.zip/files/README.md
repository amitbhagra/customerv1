# Payment pipeline monitoring — Prometheus + Grafana

Reproduces the dashboard from the mockup: total throughput, p99 latency,
projection consumer lag, error rate, per-component throughput, and a
component health snapshot with color thresholds.

## 1. Quick start

```bash
cd monitoring
docker compose up -d
```

- Prometheus: http://localhost:9090
- Grafana: http://localhost:3000 (admin / admin — change this immediately)

The dashboard "Payment processing digital twin" is auto-provisioned and
will show "No data" until the exporters below are pointed at your real
infrastructure and the two apps are instrumented.

## 2. Instrumenting each component

### IBM MQ → Kafka source connector, and sink connector → subledger

Kafka Connect exposes everything as JMX MBeans. The standard way to get
these into Prometheus is the **jmx-exporter javaagent**, attached to
each Connect worker's JVM:

```bash
java -javaagent:/opt/jmx_prometheus_javaagent.jar=8080:/opt/kafka-connect.yml \
  -jar connect-standalone.jar connect-worker.properties source-connector.properties
```

`kafka-connect.yml` (minimal, expand as needed):

```yaml
lowercaseOutputName: true
rules:
  - pattern: "kafka.connect<type=connector-task-metrics, connector=(.+), task=(.+)><>(.+): (.+)"
    name: kafka_connect_task_$3
    labels:
      connector: "$1"
      task: "$2"
  - pattern: "kafka.connect<type=source-task-metrics, connector=(.+), task=(.+)><>poll-total"
    name: kafka_connect_source_task_poll_total
    labels: { connector: "$1", task: "$2" }
  - pattern: "kafka.connect<type=sink-task-metrics, connector=(.+), task=(.+)><>put-batch-avg-time-ms"
    name: kafka_connect_sink_task_put_batch_avg_time_ms
    labels: { connector: "$1", task: "$2" }
```

Run the source connector's Connect worker with port `8080` and the sink
connector's worker with `8081` (matches `prometheus.yml`), or split them
onto separate ports if they run in the same Connect cluster.

### Kafka topic and consumer lag (projection layer)

`kafka-exporter` (already in `docker-compose.yml`) talks to the broker
directly and exposes topic offsets and consumer group lag — no code
changes needed. Just point `--kafka.server` at your real broker(s) and
`--group.filter` at the projection layer's actual consumer group id.

### Projection layer and Balance API (your own services)

Instrument these directly with a Prometheus client library and expose
a `/metrics` endpoint.

Node.js (`prom-client`), Balance API example:

```js
const client = require('prom-client');
const register = new client.Registry();
client.collectDefaultMetrics({ register });

const requestsTotal = new client.Counter({
  name: 'balance_api_requests_total',
  help: 'Total balance API requests',
  labelNames: ['status'],
  registers: [register]
});

const requestDuration = new client.Histogram({
  name: 'balance_api_request_duration_seconds',
  help: 'Balance API request duration',
  buckets: [0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1],
  registers: [register]
});

app.get('/metrics', async (req, res) => {
  res.set('Content-Type', register.contentType);
  res.end(await register.metrics());
});
```

Java (Micrometer), Projection layer example:

```java
MeterRegistry registry = new PrometheusMeterRegistry(PrometheusConfig.DEFAULT);
Counter recordsConsumed = Counter.builder("projection_layer_records_consumed_total")
    .description("Records consumed from the Kafka topic")
    .register(registry);

// increment per record in your consumer loop
recordsConsumed.increment();
```

Expose `registry.scrape()` on a `/metrics` HTTP endpoint (port `3001`
in `prometheus.yml`).

### MongoDB (digital twin store)

`mongodb-exporter` (already in `docker-compose.yml`) needs read access
to `serverStatus` and `dbStats`. Point `--mongodb.uri` at your real
replica set / Atlas connection string.

### Cache layer (Redis or MongoDB IM)

- **Redis**: `redis-exporter` is already included — point it at your
  cache instance.
- **MongoDB IM**: reuse `mongodb-exporter` against the in-memory
  instance with a separate job label, since it speaks the same
  `serverStatus` protocol.

## 3. Alerting

`alert_rules.yml` ships four starter alerts: high projection consumer
lag, elevated Balance API error rate, slow sink connector batches, and
low cache hit rate. Wire these to Alertmanager (Slack, PagerDuty, email)
by adding an `alerting:` block to `prometheus.yml` pointing at your
Alertmanager instance — not included here since routing is
team-specific.

## 4. Dashboard panel reference

| Panel | Query |
|---|---|
| Total throughput | `sum(rate(kafka_topic_partition_current_offset{topic=~"payments.*"}[1m])) * 60` |
| Balance API p99 latency | `histogram_quantile(0.99, sum(rate(balance_api_request_duration_seconds_bucket[5m])) by (le))` |
| Projection consumer lag | `sum(kafka_consumergroup_lag{consumergroup=~"projection-layer.*"})` |
| Error rate | `sum(rate(balance_api_requests_total{status=~"5.."}[5m])) / sum(rate(balance_api_requests_total[5m]))` |
| Cache hit rate | `redis_keyspace_hits_total / (redis_keyspace_hits_total + redis_keyspace_misses_total)` |

## 5. A note on the animated flow diagram

Grafana doesn't natively animate message flow along a topology, like
the interactive mockup did. Two practical options if you want a similar
visual in Grafana:

- **Node graph panel** (built in): shows components as nodes with
  color-coded health, using `nodeGraph` data frames — no animation, but
  a live topology view.
- **Business/Flowcharting community plugin**: lets you overlay a static
  architecture SVG with metric-driven colors and labels per shape.

Otherwise, the stat/gauge/bar-gauge panels in this dashboard give you
the same signal (throughput, lag, latency, health) without needing a
plugin.
