# Adding the payment pipeline dashboard to an existing Prometheus + Grafana (Docker)

This guide assumes you already have Prometheus and Grafana running as
Docker containers (or Docker Compose services) and just want to wire in
the payment processing digital twin dashboard, exporters, and alerts —
without redeploying your existing stack.

Files referenced below:
- `prometheus.yml` — scrape config to merge into your existing one
- `alert_rules.yml` — alerting rules to load into Prometheus
- `grafana/dashboards/payment-pipeline-dashboard.json` — the dashboard to import

## 1. Deploy the exporters

Each exporter is a small standalone container that translates a
system's native stats into Prometheus metrics. Run these alongside
your existing stack — they don't need to be on the same Docker network
as Prometheus/Grafana as long as Prometheus can reach their ports.

### kafka-exporter (topic throughput + consumer lag)

```bash
docker run -d --name kafka-exporter -p 9308:9308 \
  danielqsj/kafka-exporter \
  --kafka.server=broker1.yourdomain.com:9092 \
  --kafka.server=broker2.yourdomain.com:9092 \
  --topic.filter="payments.*" \
  --group.filter="projection-layer.*"
```

If your Kafka requires SASL/TLS:
```bash
docker run -d --name kafka-exporter -p 9308:9308 \
  -v /path/to/certs:/certs \
  danielqsj/kafka-exporter \
  --kafka.server=broker1.yourdomain.com:9092 \
  --sasl.enabled --sasl.username=<user> --sasl.password=<pass> \
  --sasl.mechanism=SCRAM-SHA-256 \
  --tls.enabled --tls.ca-file=/certs/ca.pem
```

### mongodb-exporter (digital twin store)

```bash
docker run -d --name mongodb-exporter -p 9216:9216 \
  percona/mongodb_exporter:0.42 \
  --mongodb.uri="mongodb://readonly-user:pass@mongo-host1:27017,mongo-host2:27017/?replicaSet=rs0&authSource=admin" \
  --collect-all
```

Use a read-only user with `clusterMonitor` and `read` roles on
`admin`/`local`. Atlas connection strings work as-is.

### redis-exporter (cache layer, if using Redis)

```bash
docker run -d --name redis-exporter -p 9121:9121 \
  oliver006/redis_exporter \
  --redis.addr=redis://cache-host:6379 \
  --redis.password=<your-redis-password>
```

For TLS (e.g. ElastiCache with encryption in transit): use
`rediss://cache-host:6379` instead.

**Using MongoDB IM for the cache instead of Redis?** Skip
redis-exporter. Run a second `mongodb-exporter` container pointed at
the IM instance's URI, on a different port (e.g. `9217`):

```bash
docker run -d --name mongodb-im-exporter -p 9217:9216 \
  percona/mongodb_exporter:0.42 \
  --mongodb.uri="mongodb://user:pass@mongo-im-host:27017" \
  --collect-all
```

### Kafka Connect (source + sink connectors) — JMX exporter javaagent

Kafka Connect metrics live inside the worker's JVM, so instead of a
separate exporter container, attach the **jmx_prometheus_javaagent**
directly to the Connect process.

**On the host/container running Kafka Connect:**

1. Download the agent:
   ```bash
   curl -L -o /opt/jmx_prometheus_javaagent.jar \
     https://repo1.maven.org/maven2/io/prometheus/jmx/jmx_prometheus_javaagent/0.20.0/jmx_prometheus_javaagent-0.20.0.jar
   ```

2. Save this as `/opt/kafka-connect.yml`:
   ```yaml
   lowercaseOutputName: true
   rules:
     - pattern: "kafka.connect<type=connector-task-metrics, connector=(.+), task=(.+)><>(.+): (.+)"
       name: kafka_connect_task_$3
       labels:
         connector: "$1"
         task: "$2"
     - pattern: "kafka.connect<type=source-task-metrics, connector=(.+), task=(.+)><>poll-total"
       name: kafka_connect_source_task_poll_total
       labels: { connector: "$1", task: "$2" }
     - pattern: "kafka.connect<type=sink-task-metrics, connector=(.+), task=(.+)><>put-batch-avg-time-ms"
       name: kafka_connect_sink_task_put_batch_avg_time_ms
       labels: { connector: "$1", task: "$2" }
   ```

3. Add the javaagent flag when the worker starts:
   - **Bare process:**
     ```bash
     export KAFKA_OPTS="-javaagent:/opt/jmx_prometheus_javaagent.jar=8080:/opt/kafka-connect.yml"
     connect-distributed.sh connect-worker.properties
     ```
   - **Docker (e.g. confluentinc/cp-kafka-connect):** add to the
     container's environment and mount the two files:
     ```yaml
     environment:
       KAFKA_OPTS: "-javaagent:/opt/jmx_prometheus_javaagent.jar=8080:/opt/kafka-connect.yml"
     volumes:
       - ./jmx_prometheus_javaagent.jar:/opt/jmx_prometheus_javaagent.jar
       - ./kafka-connect.yml:/opt/kafka-connect.yml
     ports:
       - "8080:8080"
     ```

4. If the sink connector runs on a **separate** Connect worker, repeat
   with a different port (e.g. `8081`). If source and sink share one
   Connect cluster, one javaagent is enough — the `connector=` label
   in the JMX rules already distinguishes them.

### Balance API and projection layer (your own services)

These are your applications, so they need Prometheus client libraries
added directly, not a bolt-on exporter.

**Balance API (Node.js, `prom-client`):**
```js
const client = require('prom-client');
const register = new client.Registry();
client.collectDefaultMetrics({ register });

const requestsTotal = new client.Counter({
  name: 'balance_api_requests_total',
  help: 'Total balance API requests',
  labelNames: ['status'],
  registers: [register]
});

const requestDuration = new client.Histogram({
  name: 'balance_api_request_duration_seconds',
  help: 'Balance API request duration',
  buckets: [0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1],
  registers: [register]
});

app.get('/metrics', async (req, res) => {
  res.set('Content-Type', register.contentType);
  res.end(await register.metrics());
});
```

**Projection layer (Java, Micrometer):**
```java
MeterRegistry registry = new PrometheusMeterRegistry(PrometheusConfig.DEFAULT);
Counter recordsConsumed = Counter.builder("projection_layer_records_consumed_total")
    .description("Records consumed from the Kafka topic")
    .register(registry);

recordsConsumed.increment(); // call per record in the consumer loop
```

Expose `registry.scrape()` (or the Node registry) on a `/metrics` HTTP
endpoint in each service.

## 2. Add scrape jobs to your existing Prometheus

Find the `prometheus.yml` your running Prometheus container already
mounts (check with `docker inspect <prometheus-container> --format '{{ .Mounts }}'`
if unsure), and add these jobs to its `scrape_configs:` section:

```yaml
scrape_configs:
  - job_name: kafka-connect-source
    static_configs:
      - targets: ["connect-worker-host:8080"]
        labels: { component: "source-connector" }

  - job_name: kafka-connect-sink
    static_configs:
      - targets: ["connect-worker-host:8081"]
        labels: { component: "sink-connector" }

  - job_name: kafka-exporter
    static_configs:
      - targets: ["<host-running-kafka-exporter>:9308"]
        labels: { component: "kafka-topic" }

  - job_name: mongodb-exporter
    static_configs:
      - targets: ["<host-running-mongodb-exporter>:9216"]
        labels: { component: "mongodb" }

  - job_name: redis-exporter
    static_configs:
      - targets: ["<host-running-redis-exporter>:9121"]
        labels: { component: "cache" }

  - job_name: balance-api
    metrics_path: /metrics
    static_configs:
      - targets: ["balance-api-host:3000"]
        labels: { component: "balance-api" }

  - job_name: projection-layer
    metrics_path: /metrics
    static_configs:
      - targets: ["projection-layer-host:3001"]
        labels: { component: "projection-layer" }
```

Omit the `kafka-connect-sink` job if source and sink connectors share
one Connect worker/port.

**Docker networking note:** if the exporters and Prometheus are on
different Docker networks, either put them on the same
`docker network` (`docker network connect <network> <container>`), or
use the host machine's reachable IP/hostname instead of the container
name.

## 3. Load the alerting rules

Copy `alert_rules.yml` to wherever your Prometheus container mounts
its config directory, then reference it in `prometheus.yml`:

```yaml
rule_files:
  - alert_rules.yml
```

## 4. Apply the config changes

If Prometheus was started with `--web.enable-lifecycle`, reload without
a restart:
```bash
curl -X POST http://<prometheus-host>:9090/-/reload
```
Otherwise, restart the container:
```bash
docker restart <prometheus-container-name>
```

**Verify:** open `http://<prometheus-host>:9090/targets` — every job
added above should show as **UP** once its exporter/app is reachable.

## 5. Import the dashboard into Grafana

1. Open your existing Grafana instance and confirm a Prometheus
   datasource is configured: **Connections → Data sources**. Note its
   name/UID (you'll need it during import).
2. Go to **Dashboards → New → Import**.
3. Click **Upload dashboard JSON file** and select
   `grafana/dashboards/payment-pipeline-dashboard.json`.
4. On the import screen, Grafana detects the `Prometheus` datasource
   variable used by the dashboard's panels — select your existing
   datasource from the dropdown next to it.
5. Click **Import**.

The dashboard "Payment processing digital twin" will now appear in
your dashboard list with panels for total throughput, Balance API p99
latency, projection consumer lag, error rate, per-component
throughput, and a component health snapshot.

## 6. Confirm data is flowing

- Panels show **No data** until Prometheus has scraped at least one
  successful sample from each target (up to one scrape interval, ~15s
  by default).
- If a panel stays empty, check that target's status on the
  Prometheus targets page first — most gaps trace back to an
  unreachable exporter or a metric name mismatch.

## Panel query reference

| Panel | Query |
|---|---|
| Total throughput | `sum(rate(kafka_topic_partition_current_offset{topic=~"payments.*"}[1m])) * 60` |
| Balance API p99 latency | `histogram_quantile(0.99, sum(rate(balance_api_request_duration_seconds_bucket[5m])) by (le))` |
| Projection consumer lag | `sum(kafka_consumergroup_lag{consumergroup=~"projection-layer.*"})` |
| Error rate | `sum(rate(balance_api_requests_total{status=~"5.."}[5m])) / sum(rate(balance_api_requests_total[5m]))` |
| Cache hit rate | `redis_keyspace_hits_total / (redis_keyspace_hits_total + redis_keyspace_misses_total)` |

If your metric names differ from the ones above (common with managed
services like MSK, Atlas, or ElastiCache), edit the panel queries
directly in Grafana's dashboard editor (Edit panel → adjust the PromQL
expression → Apply → Save dashboard).
